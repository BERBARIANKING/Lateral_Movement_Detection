# graph_utils.py

import networkx as nx
import pandas as pd

def build_network(logon_df: pd.DataFrame,
                  file_df: pd.DataFrame,
                  device_df: pd.DataFrame) -> nx.Graph:
    """
    Construct a NetworkX graph where:
    - Nodes: users (type='user') and hosts (type='host')
    - Edges: interactions (logon, file, usb) with weights + interaction types
    """
    G = nx.Graph()

    # Add user nodes
    users = logon_df['user'].unique()
    G.add_nodes_from(users, type='user')

    # Add host nodes (from all three logs)
    hosts = pd.concat([logon_df['pc'], file_df['pc'], device_df['pc']]).unique()
    G.add_nodes_from(hosts, type='host')

    # Helper to add or update edges
    def add_edges(df, interaction_label):
        grouped = df.groupby(['user', 'pc']).size().reset_index(name='weight')
        for _, row in grouped.iterrows():
            u, h, w = row['user'], row['pc'], int(row['weight'])
            if G.has_edge(u, h):
                G[u][h]['weight'] += w
                G[u][h]['interaction'] += f'+{interaction_label}'
            else:
                G.add_edge(u, h,
                           weight=w,
                           interaction=interaction_label)

    # Add edges for each activity type
    add_edges(logon_df, 'logon')
    add_edges(file_df, 'file')
    add_edges(device_df, 'usb')

    return G
