

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("network-graph");
  if (!container) return;

  fetch("/graph-data")
    .then(r => r.json())
    .then(data => {
      // Icon lookup
      const icons = {
        client:   "/static/images/client.png",
        server:   "/static/images/server.png",
        firewall: "/static/images/firewall.png",
        internet: "/static/images/internet.png",
      };

      // Prepare nodes with images & borders
      const visNodes = data.nodes.map(n => ({
        id: n.id,
        label: n.label,
        shape: "image",
        image: icons[n.category],
        size: 32,
        borderWidth: n.is_anomaly ? 4 : 1,
        color: {
          border: n.is_anomaly ? "orange" : "#666",
          background: "transparent"
        }
      }));
      const nodes = new vis.DataSet(visNodes);
      const edges = new vis.DataSet(data.edges);

      // Use ForceAtlas2 for cleaner layout and avoid overlap
      const options = {
        physics: {
          enabled: true,
          solver: 'forceAtlas2Based',
          forceAtlas2Based: {
            gravitationalConstant: -50,
            centralGravity: 0.01,
            springLength: 200,
            springConstant: 0.08,
            damping: 0.4,
            avoidOverlap: 1
          },
          stabilization: {
            enabled: true,
            iterations: 2000,
            updateInterval: 100
          }
        },
        interaction: {
          hover: true,
          dragNodes: true,
          dragView: true
        }
      };

      const network = new vis.Network(container, { nodes, edges }, options);

      // After stabilization, lock positions
      network.once("stabilizationIterationsDone", () =>
        network.setOptions({ physics: { enabled: false } })
      );

      // Ego-network filter
      network.on("selectNode", params => {
        const sel = params.nodes[0];
        const keep = new Set([sel]);
        edges.forEach(e => {
          if (e.from === sel || e.to === sel) {
            keep.add(e.from);
            keep.add(e.to);
          }
        });
        nodes.forEach(n => nodes.update({ id: n.id, hidden: !keep.has(n.id) }));
        edges.forEach(e => edges.update({ id: e.id, hidden: !(e.from === sel || e.to === sel) }));
      });
      network.on("deselectNode", () => {
        nodes.forEach(n => nodes.update({ id: n.id, hidden: false }));
        edges.forEach(e => edges.update({ id: e.id, hidden: false }));
      });

      // Click to highlight & show logs
      network.on("click", params => {
        if (params.nodes.length === 1) {
          const id = params.nodes[0];
          nodes.update({ id, borderWidth: 6, color: { border: "red" } });
          fetch(`/user/${encodeURIComponent(id)}`)
            .then(r => r.text())
            .then(html => {
              const doc   = new DOMParser().parseFromString(html,"text/html");
              const items = doc.querySelectorAll("ul li");
              const panel = document.getElementById("log-panel");
              const list  = document.getElementById("log-list");
              document.getElementById("log-user").textContent = `Logs for ${id}`;
              list.innerHTML = "";
              items.forEach(li => list.appendChild(li));
              panel.style.display = "block";
            });
        }
      });
    })
    .catch(console.error);
});
