# generate_cert_subset.py
import os
import pandas as pd

def main():
    RAW = os.path.join("data", "raw_cert")
    OUT = os.path.join("data", "subset")
    os.makedirs(OUT, exist_ok=True)

    # 1) Pick 10 users at random
    users_df = pd.read_csv(os.path.join(RAW, "users.csv"))
    chosen = users_df['user'].sample(10, random_state=42).tolist()

    # 2) Define a 7‑day window
    start, end = "2020-01-15", "2020-01-22"

    def subset_file(fname, user_col="user"):
        df = pd.read_csv(os.path.join(RAW, fname))
        # Keep only chosen users
        df = df[df[user_col].isin(chosen)]
        # If there's a date column, filter to the window
        if 'date' in df.columns:
            df = df[df['date'].between(start, end)]
        df.to_csv(os.path.join(OUT, fname), index=False)
        print(f"Wrote {OUT}/{fname} ({len(df)} rows)")

    # Subset event files
    for f in ["logon.csv", "device.csv", "file.csv"]:
        subset_file(f)

    # Subset users & psychometric
    pd.read_csv(os.path.join(RAW, "users.csv")) \
      .query("user in @chosen") \
      .to_csv(os.path.join(OUT, "users.csv"), index=False)
    pd.read_csv(os.path.join(RAW, "psychometric.csv")) \
      .query("user in @chosen") \
      .to_csv(os.path.join(OUT, "psychometric.csv"), index=False)

    print("✅ CERT subset generated in data/subset/")

if __name__ == "__main__":
    main()
