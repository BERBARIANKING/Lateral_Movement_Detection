# gnn_model.py

import torch
import torch.nn.functional as F
import torch.nn as nn
from torch_geometric.nn import SAGEConv
from torch_geometric.utils import from_networkx

class GraphSAGE(nn.Module):
    def __init__(self, in_channels, hidden_channels, num_layers=2):
        """
        in_channels: dimensionality of input features
        hidden_channels: hidden representation size
        num_layers: total number of SAGEConv layers
        """
        super().__init__()
        self.convs = nn.ModuleList()
        # First layer
        self.convs.append(SAGEConv(in_channels, hidden_channels))
        # Additional layers
        for _ in range(num_layers-1):
            self.convs.append(SAGEConv(hidden_channels, hidden_channels))
        # Final linear layer to produce a single score per node
        self.lin = nn.Linear(hidden_channels, 1)

    def forward(self, x, edge_index):
        # Pass through each GraphSAGE layer + ReLU
        for conv in self.convs:
            x = conv(x, edge_index)
            x = F.relu(x)
        # Linear readout to a single value per node
        return self.lin(x).squeeze()

class GNNAnomalyDetector:
    def __init__(self, graph, features):
        """
        graph: a NetworkX graph containing your nodes/edges
        features: numpy array of shape [num_nodes, feat_dim]
        """
        # Convert to PyG data object
        pyg_data = from_networkx(graph)
        pyg_data.x = torch.tensor(features, dtype=torch.float)
        pyg_data.edge_index = pyg_data.edge_index  # ensure edges are set
        self.data = pyg_data

        # Instantiate GraphSAGE model
        in_dim = features.shape[1]
        self.model = GraphSAGE(in_dim, hidden_channels=16)

    def train(self, epochs=50, lr=0.01):
        """
        Self‑supervised training:
        We train to predict each node’s feature‑norm from its neighbors.
        """
        optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
        for epoch in range(epochs):
            self.model.train()
            optimizer.zero_grad()
            pred = self.model(self.data.x, self.data.edge_index)
            # Use MSE between prediction and the L2‑norm of original features
            loss = F.mse_loss(pred, self.data.x.norm(dim=1))
            loss.backward()
            optimizer.step()
            # Optionally print or log loss:
            # if epoch % 10 == 0:
            #     print(f"[GNN] Epoch {epoch}: loss = {loss.item():.4f}")

    def anomaly_scores(self):
        """
        After training, return each node’s predicted value
        as its anomaly score (higher = more anomalous).
        """
        self.model.eval()
        with torch.no_grad():
            scores = self.model(self.data.x, self.data.edge_index)
        return scores.numpy()
