# app.py

from flask import Flask, request, render_template, jsonify
import pandas as pd
import networkx as nx
from threading import Lock
from model import InsiderThreatModel
from graph_utils import build_network
from gnn_model import GNNAnomalyDetector
import os
import numpy as np

# Flask setup
app = Flask(__name__)
lock = Lock()

# === 1. Initialize Temporal Model (LSTM) ===
lstm = InsiderThreatModel()
if not lstm.load_model():
    lstm.train()  # trains and saves to lstm_model.keras

# === 2. Load Synthetic Data ===
BASE_DIR = os.path.dirname(__file__)
DATA_PATH = os.path.join(BASE_DIR, "data", "synthetic")

logon_df  = pd.read_csv(os.path.join(DATA_PATH, "logon.csv"))
device_df = pd.read_csv(os.path.join(DATA_PATH, "device.csv"))
file_df   = pd.read_csv(os.path.join(DATA_PATH, "file.csv"))
users_df  = pd.read_csv(os.path.join(DATA_PATH, "users.csv"))
psych_df  = pd.read_csv(os.path.join(DATA_PATH, "psychometric.csv"))

# === 3. Build Static Network Graph ===
G = build_network(logon_df, file_df, device_df)

# Use node degree as a simple feature
features = np.array([G.degree(n) for n in G.nodes()]).reshape(-1, 1)

# === 4. Initialize & Train Structural Model (GraphSAGE) ===
gnn = GNNAnomalyDetector(G, features)
gnn.train()  # trains the GNN on self-supervised reconstruction

# Compute a structural anomaly score per node
struct_scores = dict(zip(G.nodes(), gnn.anomaly_scores()))

# === 5. In-Memory State for Streaming Logs ===
SEQ_LEN = 10  # must match the LSTM's SEQ_LEN
user_seqs = {u: [] for u in users_df['user']}
seq_anoms = []  # list of detected sequential anomalies

# === 6. Flask Routes ===

@app.route("/")
def index():
    """Main dashboard: shows network graph + user list."""
    graph_html = graph_view()  # reuse the graph route’s HTML snippet
    users = users_df['user'].tolist()
    return render_template("index.html", graph=graph_html, users=users)

@app.route("/status")
def status():
    """Health check."""
    return jsonify({"status": "ok"})

@app.route("/log", methods=["POST"])
def ingest_log():
    """
    Ingest a new log event:
    POST JSON { "user":..., "pc":..., "timestamp":... }
    """
    data = request.get_json()
    user = data["user"]
    pc   = data["pc"]
    ts   = data["timestamp"]

    with lock:
        seq = user_seqs.setdefault(user, [])
        # encode the host, update sliding window
        enc = lstm.host_encoder.transform([pc])[0]
        seq.append(enc)
        if len(seq) > SEQ_LEN:
            seq = seq[-SEQ_LEN:]
        user_seqs[user] = seq

        # once we have SEQ_LEN events, score for anomaly
        if len(seq) == SEQ_LEN:
            score = lstm.predict_score(seq)
            if score > 5:  # threshold can be tuned
                seq_anoms.append({
                    "user": user,
                    "pc": pc,
                    "timestamp": ts,
                    "lstm_score": float(score)
                })

    return jsonify({"ingested": True})

@app.route("/alerts")
def alerts():
    """Return top sequential + top structural anomalies as JSON."""
    out = []
    # Top 5 temporal anomalies
    for a in sorted(seq_anoms, key=lambda x: -x["lstm_score"])[:5]:
        out.append(a)
    # Top 5 structural anomalies
    for node, s in sorted(struct_scores.items(), key=lambda x: -x[1])[:5]:
        out.append({"node": node, "struct_score": float(s)})
    return jsonify(out)

@app.route("/graph")
def graph_view():
    """
    Build and return an HTML snippet of the Plotly network graph,
    coloring high-structural-anomaly nodes in purple.
    """
    pos = nx.spring_layout(G, seed=42)
    import plotly.graph_objects as go

    # Edges
    edge_x, edge_y = [], []
    for u, v in G.edges():
        x0, y0 = pos[u]; x1, y1 = pos[v]
        edge_x += [x0, x1, None]
        edge_y += [y0, y1, None]
    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        mode="lines",
        line=dict(color="#888")
    )

    # Nodes
    node_x, node_y, node_color, node_text = [], [], [], []
    threshold = np.mean(list(struct_scores.values()))
    for n in G.nodes():
        x, y = pos[n]
        node_x.append(x); node_y.append(y)
        # Highlight if structural score > mean
        if struct_scores[n] > threshold:
            node_color.append("purple")
        else:
            node_color.append("blue" if G.nodes[n]["type"] == "user" else "green")
        node_text.append(n)

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        marker=dict(size=20, color=node_color),
        text=node_text,
        textposition="top center"
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(showlegend=False, margin=dict(t=0, b=0, l=0, r=0))
    return fig.to_html(full_html=False)

@app.route("/user/<user_id>")
def user_detail(user_id):
    """Render details for a specific user’s logs & sequential anomalies."""
    logs = logon_df[logon_df["user"] == user_id].to_dict(orient="records")
    anoms = [a for a in seq_anoms if a["user"] == user_id]
    return render_template("user.html", user=user_id, logs=logs, anomalies=anoms)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
