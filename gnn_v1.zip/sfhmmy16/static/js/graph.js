// static/js/graph.js

// Placeholder for future enhancements.
// E.g., listen for click events in the Plotly graph:
document.addEventListener('DOMContentLoaded', function() {
    const graphDiv = document.getElementById('network-graph').querySelector('div');
    if (!graphDiv) return;
  
    graphDiv.on('plotly_click', function(data){
      const point = data.points[0];
      const nodeName = point.text;
      // e.g., redirect to user detail
      if (point.fullData.mode === 'markers+text') {
        window.location.href = `/user/${encodeURIComponent(nodeName)}`;
      }
    });
  });
  