# generate_synthetic_data.py
"""
Generate a small synthetic CERT‑style insider threat dataset
for rapid development and testing.

Creates the following CSVs under data/synthetic/:
  - logon.csv
  - device.csv
  - file.csv
  - users.csv
  - psychometric.csv
"""

import os
import random
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# --- Configuration ---
OUT_DIR = "data/synthetic"
NUM_USERS = 30
HOST_WORKSTATIONS = 10
HOST_FILESERVERS = 3
START_DATE = datetime(2020, 1, 1)
DAYS_SPAN = 90

# Ensure reproducibility
random.seed(42)
np.random.seed(42)

# --- Prepare users and hosts ---
users = [f"user{i:02d}" for i in range(1, NUM_USERS + 1)]
workstations = [f"workstation{i}" for i in range(1, HOST_WORKSTATIONS + 1)]
fileservers   = [f"fileserver{i}"   for i in range(1, HOST_FILESERVERS + 1)]
hosts = workstations + fileservers + ["domain_controller1"]

# --- logon.csv ---
logon_records = []
for user in users:
    n_events = random.randint(20, 50)
    for _ in range(n_events):
        pc = random.choice(hosts)
        dt = START_DATE + timedelta(days=random.randint(0, DAYS_SPAN))
        time_str = dt.strftime("%H:%M")
        logon_records.append({
            "user": user,
            "pc": pc,
            "date": dt.date().isoformat(),
            "time": time_str
        })
logon_df = pd.DataFrame(logon_records)

# --- device.csv (USB events) ---
device_records = []
for user in users:
    n_events = random.randint(5, 15)
    for _ in range(n_events):
        pc = random.choice(hosts)
        dt = START_DATE + timedelta(days=random.randint(0, DAYS_SPAN))
        device_records.append({
            "user": user,
            "pc": pc,
            "date": dt.date().isoformat(),
            "time": dt.strftime("%H:%M"),
            "activity": "usb_insert"
        })
device_df = pd.DataFrame(device_records)

# --- file.csv (file transfers) ---
file_types = ["docx", "pdf", "xls", "ppt"]
file_records = []
for user in users:
    n_events = random.randint(10, 30)
    for _ in range(n_events):
        pc = random.choice(hosts)
        dt = START_DATE + timedelta(days=random.randint(0, DAYS_SPAN))
        filename = f"file_{random.randint(1000,9999)}.{random.choice(file_types)}"
        file_records.append({
            "user": user,
            "pc": pc,
            "date": dt.date().isoformat(),
            "time": dt.strftime("%H:%M"),
            "filename": filename
        })
file_df = pd.DataFrame(file_records)

# --- users.csv (metadata) ---
departments = ["Engineering", "Finance", "HR", "Research"]
roles       = ["Analyst", "Manager", "Engineer", "Admin"]
users_meta = []
for user in users:
    users_meta.append({
        "user": user,
        "dept": random.choice(departments),
        "role": random.choice(roles)
    })
users_df = pd.DataFrame(users_meta)

# --- psychometric.csv (OCEAN traits) ---
traits = ["O", "C", "E", "A", "N"]
psych_records = []
for user in users:
    row = { t: float(np.random.normal(50, 10)) for t in traits }
    row["user"] = user
    psych_records.append(row)
psychometric_df = pd.DataFrame(psych_records)

# --- Write to disk ---
os.makedirs(OUT_DIR, exist_ok=True)
logon_df.to_csv(f"{OUT_DIR}/logon.csv", index=False)
device_df.to_csv(f"{OUT_DIR}/device.csv", index=False)
file_df.to_csv(f"{OUT_DIR}/file.csv", index=False)
users_df.to_csv(f"{OUT_DIR}/users.csv", index=False)
psychometric_df.to_csv(f"{OUT_DIR}/psychometric.csv", index=False)

print(f"Synthetic dataset generated under '{OUT_DIR}'")
