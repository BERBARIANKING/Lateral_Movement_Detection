# model.py
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.losses import MeanSquaredError

# Constants
data_dir = os.path.dirname(__file__)
DATA_PATH = os.path.join(os.path.dirname(__file__), 'data', 'synthetic')  # point to synthetic data
MODEL_PATH = os.path.join(data_dir, 'lstm_model.keras')  # native Keras format
SEQ_LEN = 10

class InsiderThreatModel:
    def __init__(self):
        self.host_encoder = LabelEncoder()
        self.scaler = MinMaxScaler()
        self.model = None

    def load_data(self):
        logon = pd.read_csv(os.path.join(DATA_PATH, 'logon.csv'))
        logon['datetime'] = pd.to_datetime(logon['date'] + ' ' + logon['time'])
        logon.sort_values(['user', 'datetime'], inplace=True)
        logon['pc_encoded'] = self.host_encoder.fit_transform(logon['pc'])
        return logon

    def prepare_sequences(self, logon_df):
        sequences, labels = [], []
        for user, group in logon_df.groupby('user'):
            enc = group['pc_encoded'].values
            for i in range(len(enc) - SEQ_LEN):
                sequences.append(enc[i:i+SEQ_LEN])
                labels.append(enc[i+SEQ_LEN])
        X = pad_sequences(sequences, padding='post')
        y = np.array(labels)
        # Normalize across features
        X = self.scaler.fit_transform(X)
        X = X.reshape((X.shape[0], SEQ_LEN, 1))
        return X, y

    def build_model(self):
        loss_fn = MeanSquaredError()
        model = Sequential([
            LSTM(64, input_shape=(SEQ_LEN, 1)),
            Dropout(0.3),
            Dense(32, activation='relu'),
            Dense(1, activation='linear'),
        ])
        model.compile(optimizer='adam', loss=loss_fn)
        self.model = model
        return model

    def train(self, epochs=5, batch_size=32):
        logon_df = self.load_data()
        X, y = self.prepare_sequences(logon_df)
        self.build_model()
        self.model.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=0.2
        )
        # Save in native Keras format for better compatibility
        self.model.save(MODEL_PATH)

    def load_model(self):
        if os.path.exists(MODEL_PATH):
            # Load without compilation to avoid legacy loss issues
            self.model = load_model(MODEL_PATH, compile=False)
            # Recompile with current loss function
            self.model.compile(optimizer='adam', loss=MeanSquaredError())
            return True
        return False

    def predict_score(self, sequence):
        arr = np.array(sequence).reshape(1, SEQ_LEN)
        arr = self.scaler.transform(arr)
        arr = arr.reshape((1, SEQ_LEN, 1))
        pred = self.model.predict(arr, verbose=0)[0][0]
        return abs(pred - sequence[-1])
