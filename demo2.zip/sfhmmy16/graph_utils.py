# graph_utils.py
import pandas as pd
import networkx as nx

def build_network(logon_df: pd.DataFrame,
                  file_df: pd.DataFrame,
                  device_df: pd.DataFrame) -> nx.Graph:
    """
    Build a NetworkX graph from logon, file-transfer, and device logs.
    - Nodes: users (type='user') and hosts (type='host')
    - Edges: interactions with weights and types
    """
    G = nx.Graph()

    # Add user nodes
    users = logon_df['user'].unique()
    G.add_nodes_from(users, type='user')

    # Collect all hosts seen in any dataset
    hosts = pd.concat([
        logon_df['pc'],
        file_df['pc'],
        device_df['pc']
    ]).unique()
    G.add_nodes_from(hosts, type='host')

    # Add edges for logon activity
    logon_edges = (
        logon_df
        .groupby(['user', 'pc'])
        .size()
        .reset_index(name='weight')
    )
    for _, row in logon_edges.iterrows():
        G.add_edge(
            row['user'],
            row['pc'],
            weight=int(row['weight']),
            interaction='logon'
        )

    # Add edges for file-transfer activity
    file_edges = (
        file_df
        .groupby(['user', 'pc'])
        .size()
        .reset_index(name='weight')
    )
    for _, row in file_edges.iterrows():
        # If an edge already exists, you can sum weights or overwrite
        if G.has_edge(row['user'], row['pc']):
            G[row['user']][row['pc']]['weight'] += int(row['weight'])
            G[row['user']][row['pc']]['interaction'] += '+file'
        else:
            G.add_edge(
                row['user'],
                row['pc'],
                weight=int(row['weight']),
                interaction='file'
            )

    # Add edges for device (USB) activity
    device_edges = (
        device_df
        .groupby(['user', 'pc'])
        .size()
        .reset_index(name='weight')
    )
    for _, row in device_edges.iterrows():
        if G.has_edge(row['user'], row['pc']):
            G[row['user']][row['pc']]['weight'] += int(row['weight'])
            G[row['user']][row['pc']]['interaction'] += '+usb'
        else:
            G.add_edge(
                row['user'],
                row['pc'],
                weight=int(row['weight']),
                interaction='usb'
            )

    return G
