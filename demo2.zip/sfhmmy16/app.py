# app.py

from flask import Flask, request, render_template, jsonify
import pandas as pd
import networkx as nx
from threading import Lock
from model import InsiderThreatModel
from graph_utils import build_network
import os

app = Flask(__name__)
lock = Lock()

# === Initialize and load the LSTM model ===
model = InsiderThreatModel()
if not model.load_model():
    # Train with default epochs/batch_size if no saved model exists
    model.train(epochs=5, batch_size=32)

# === Load static CSV data ===
DATA_PATH = os.path.join(os.path.dirname(__file__), 'data', 'synthetic')
logon_df   = pd.read_csv(os.path.join(DATA_PATH, 'logon.csv'))
device_df  = pd.read_csv(os.path.join(DATA_PATH, 'device.csv'))
file_df    = pd.read_csv(os.path.join(DATA_PATH, 'file.csv'))
users_df   = pd.read_csv(os.path.join(DATA_PATH, 'users.csv'))
psych_df   = pd.read_csv(os.path.join(DATA_PATH, 'psychometric.csv'))

# In‑memory buffers for streaming
user_sequences = {u: [] for u in users_df['user'].unique()}
anomalies = []


@app.route('/')
def index():
    """
    Main dashboard: renders the network graph and user list.
    """
    graph_html = graph_view()  # builds and returns Plotly HTML
    users = users_df['user'].tolist()
    return render_template('index.html', graph=graph_html, users=users)


@app.route('/status')
def status():
    """Health check endpoint."""
    return jsonify({
        'status': 'ok',
        'timestamp': pd.Timestamp.now().isoformat()
    })


@app.route('/prompt')
def prompt():
    """Documentation: returns the original system prompt."""
    return jsonify({
        'prompt': 'Insider threat detection Flask app'
    })


@app.route('/log', methods=['POST'])
def ingest_log():
    """
    Ingest a new logon event:
    { "user": "...", "pc": "...", "timestamp": "ISO-8601" }
    """
    data = request.get_json()
    user = data.get('user')
    pc   = data.get('pc')
    ts   = data.get('timestamp')

    with lock:
        seq = user_sequences.setdefault(user, [])
        # encode host and append
        encoded = model.host_encoder.transform([pc])[0]
        seq.append(encoded)
        # keep only last SEQ_LEN items
        if len(seq) > model.SEQ_LEN:
            seq = seq[-model.SEQ_LEN:]
            user_sequences[user] = seq

        # if we have enough history, score for anomaly
        if len(seq) == model.SEQ_LEN:
            score = model.predict_score(seq)
            if score > 5:  # threshold can be tuned
                anomalies.append({
                    'user': user,
                    'pc': pc,
                    'timestamp': ts,
                    'score': float(score)
                })

    return jsonify({'ingested': True})


@app.route('/alerts')
def get_alerts():
    """
    Return the top 10 anomalous events as JSON.
    """
    top10 = sorted(anomalies, key=lambda a: -a['score'])[:10]
    return jsonify(top10)


@app.route('/graph')
def graph_view():
    """
    Build the enterprise network topology and
    render it as Plotly HTML snippet.
    """
    # Build the graph
    G = build_network(logon_df, file_df, device_df)

    # Use NetworkX to compute positions
    pos = nx.spring_layout(G, seed=42)

    # Plotly edge traces
    import plotly.graph_objects as go
    edge_x, edge_y = [], []
    for u,v in G.edges():
        x0,y0 = pos[u]; x1,y1 = pos[v]
        edge_x += [x0, x1, None]
        edge_y += [y0, y1, None]

    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        mode='lines',
        line=dict(width=1, color='#888')
    )

    # Plotly node traces
    node_x, node_y, node_color, node_text = [], [], [], []
    for n in G.nodes():
        x,y = pos[n]
        node_x.append(x); node_y.append(y)
        # Color red if this node (user) has any anomaly
        if any(a['user']==n for a in anomalies):
            node_color.append('red')
        else:
            node_color.append('blue' if G.nodes[n]['type']=='user' else 'green')
        node_text.append(n)

    node_trace = go.Scatter(
        x=node_x, y=node_y, mode='markers+text',
        marker=dict(size=20, color=node_color),
        text=node_text, textposition='top center'
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        showlegend=False,
        margin=dict(t=0, b=0, l=0, r=0)
    )
    return fig.to_html(full_html=False)


@app.route('/user/<user_id>')
def user_detail(user_id):
    """
    Show detailed logs and anomalies for a specific user.
    """
    logs  = logon_df[logon_df['user'] == user_id].to_dict(orient='records')
    anoms = [a for a in anomalies if a['user'] == user_id]
    return render_template(
        'user.html',
        user=user_id,
        logs=logs,
        anomalies=anoms
    )


if __name__ == '__main__':
    # For development only; use Gunicorn in production
    app.run(host='0.0.0.0', port=5000, debug=True)
