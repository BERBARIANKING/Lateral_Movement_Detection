# app.py

from flask import Flask, request, render_template, jsonify
import pandas as pd
import networkx as nx
from threading import Lock
from model import InsiderThreatModel
from graph_utils import build_network
from gnn_model import GNNAnomalyDetector
import os
import numpy as np

# Flask setup
app = Flask(__name__)
lock = Lock()

# === 1. Initialize Temporal Model (LSTM) ===
lstm = InsiderThreatModel()
if not lstm.load_model():
    lstm.train()  # trains and saves to lstm_model.keras

# === 2. Load Synthetic Data ===
BASE_DIR = os.path.dirname(__file__)
DATA_PATH = os.path.join(BASE_DIR, "data", "synthetic")

logon_df  = pd.read_csv(os.path.join(DATA_PATH, "logon.csv"))
device_df = pd.read_csv(os.path.join(DATA_PATH, "device.csv"))
file_df   = pd.read_csv(os.path.join(DATA_PATH, "file.csv"))
users_df  = pd.read_csv(os.path.join(DATA_PATH, "users.csv"))
psych_df  = pd.read_csv(os.path.join(DATA_PATH, "psychometric.csv"))

# === 3. Build Static Network Graph ===
G = build_network(logon_df, file_df, device_df)

# Use node degree as a simple feature
features = np.array([G.degree(n) for n in G.nodes()]).reshape(-1, 1)

# === 4. Initialize & Train Structural Model (GraphSAGE) ===
gnn = GNNAnomalyDetector(G, features)
gnn.train()  # trains the GNN on self-supervised reconstruction

# Compute a structural anomaly score per node
struct_scores = dict(zip(G.nodes(), gnn.anomaly_scores()))

# === 5. In-Memory State for Streaming Logs ===
SEQ_LEN = 10  # must match the LSTM's SEQ_LEN
user_seqs = {u: [] for u in users_df['user']}
seq_anoms = []  # list of detected sequential anomalies

# === 6. Index Route (dashboard) ===
@app.route("/")
def index():
    """
    Main dashboard: renders index.html, passing the user list.
    """
    users = users_df['user'].tolist()
    return render_template("index.html", users=users)

# === 7. JSON Endpoint for vis-network ===
@app.route("/graph-data")
def graph_data():
    """
    Emit all nodes (clients, servers, firewall, internet) and edges.
    """
    threshold = np.mean(list(struct_scores.values()))
    nodes = []
    # 1) Core CERT-based nodes:
    for n in G.nodes():
        # Cast to native Python bool to ensure JSON serializable
        is_anom = bool(struct_scores[n] > threshold)
        kind = G.nodes[n]["type"]  # 'user' or 'host'
        category = "client" if kind == "user" else "server"
        nodes.append({
            "id": n,
            "label": n,
            "category": category,
            "is_anomaly": is_anom
        })

    # 2) Add a Firewall node
    fw_id = "Firewall"
    nodes.append({
      "id": fw_id,
      "label": "Firewall",
      "category": "firewall",
      "is_anomaly": False
    })
    # 3) Add an Internet node
    inet_id = "Internet"
    nodes.append({
      "id": inet_id,
      "label": "Internet",
      "category": "internet",
      "is_anomaly": False
    })

    # Build edges:
    edges = []
    # a) existing G edges
    for u, v in G.edges():
        edges.append({"from": u, "to": v})
    # b) firewall sits between each host and Internet
    for h in G.nodes():
        if G.nodes[h]["type"] == "host":
            edges.append({"from": h, "to": fw_id})
    # c) connect firewall → Internet
    edges.append({"from": fw_id, "to": inet_id})

    return jsonify({"nodes": nodes, "edges": edges})

# === 8. Alerts Endpoint ===
@app.route("/alerts")
def alerts():
    """
    Return top sequential + top structural anomalies as JSON.
    """
    out = []
    # Top 5 temporal anomalies
    for a in sorted(seq_anoms, key=lambda x: -x["lstm_score"])[:5]:
        out.append(a)
    # Top 5 structural anomalies
    for node, s in sorted(struct_scores.items(), key=lambda x: -x[1])[:5]:
        out.append({"node": node, "struct_score": float(s)})
    return jsonify(out)

# === 9. User Detail Endpoint ===
@app.route("/user/<user_id>")
def user_detail(user_id):
    """
    Render details for a specific user’s logs & sequential anomalies.
    """
    logs = logon_df[logon_df["user"] == user_id].to_dict(orient="records")
    anoms = [a for a in seq_anoms if a["user"] == user_id]
    return render_template("user.html", user=user_id, logs=logs, anomalies=anoms)

# === 10. Run the App ===
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
