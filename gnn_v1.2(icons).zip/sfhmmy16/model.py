# model.py
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.losses import MeanSquaredError

# Paths and constants
DATA_PATH = os.path.join(os.path.dirname(__file__), 'data', 'synthetic')
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'lstm_model.keras')
SEQ_LEN = 10

class InsiderThreatModel:
    def __init__(self):
        self.host_encoder = LabelEncoder()
        self.scaler = MinMaxScaler()
        self.model = None

    def load_data(self):
        """
        Load and preprocess logon.csv:
        - Combine date and time
        - Sort by user and datetime
        - Encode host PCs as integers
        """
        df = pd.read_csv(os.path.join(DATA_PATH, 'logon.csv'))
        df['datetime'] = pd.to_datetime(df['date'] + ' ' + df['time'])
        df.sort_values(['user', 'datetime'], inplace=True)
        df['pc_encoded'] = self.host_encoder.fit_transform(df['pc'])
        return df

    def prepare_sequences(self, df):
        """
        Convert each user's logon history into fixed-length sequences
        of SEQ_LEN events for LSTM training.
        """
        sequences, labels = [], []
        for user, group in df.groupby('user'):
            encodings = group['pc_encoded'].values
            for i in range(len(encodings) - SEQ_LEN):
                sequences.append(encodings[i:i+SEQ_LEN])
                labels.append(encodings[i+SEQ_LEN])
        X = pad_sequences(sequences, padding='post')
        y = np.array(labels)
        # Normalize
        X = self.scaler.fit_transform(X)
        # Reshape for LSTM: (samples, timesteps, features)
        X = X.reshape((X.shape[0], SEQ_LEN, 1))
        return X, y

    def build_model(self):
        """
        Define the LSTM architecture for next-host prediction.
        """
        model = Sequential([
            LSTM(64, input_shape=(SEQ_LEN, 1)),
            Dropout(0.3),
            Dense(32, activation='relu'),
            Dense(1, activation='linear'),
        ])
        model.compile(optimizer='adam', loss=MeanSquaredError())
        self.model = model
        return model

    def train(self, epochs=5, batch_size=32):
        """
        Train the LSTM on historical logon sequences.
        Saves the trained model to disk.
        """
        df = self.load_data()
        X, y = self.prepare_sequences(df)
        self.build_model()
        self.model.fit(
            X, y,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=0.2
        )
        self.model.save(MODEL_PATH)

    def load_model(self):
        """
        Load a previously saved Keras model, if available.
        Returns True if loaded, False otherwise.
        """
        if os.path.exists(MODEL_PATH):
            self.model = load_model(MODEL_PATH, compile=False)
            self.model.compile(optimizer='adam', loss=MeanSquaredError())
            return True
        return False

    def predict_score(self, sequence):
        """
        Given a recent sequence of length SEQ_LEN,
        predict the next host index and return the
        absolute error vs. the actual last element.
        """
        arr = np.array(sequence).reshape(1, SEQ_LEN)
        arr = self.scaler.transform(arr)
        arr = arr.reshape((1, SEQ_LEN, 1))
        prediction = self.model.predict(arr, verbose=0)[0][0]
        return abs(prediction - sequence[-1])
