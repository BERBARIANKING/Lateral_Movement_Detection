// static/js/graph.js

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("network-graph");
  if (!container) return;

  fetch("/graph-data")
    .then(r => r.json())
    .then(data => {
      // Icon paths
      const icons = {
        client:  "/static/images/client.png",
        server:  "/static/images/server.png",
        firewall:"/static/images/firewall.png",
        internet:"/static/images/internet.png"
      };

      // Build vis nodes
      const visNodes = data.nodes.map(n => ({
        id: n.id,
        label: n.label,
        shape: "image",
        image: icons[n.category],
        size: 32,
        borderWidth: n.is_anomaly ? 4 : 1,
        color: {
          border: n.is_anomaly ? "orange" : "#666",
          background: "transparent"
        }
      }));
      const nodes = new vis.DataSet(visNodes);
      const edges = new vis.DataSet(data.edges);

      const options = {
        physics: { stabilization: true, barnesHut: { gravitationalConstant: -8000, springLength: 250 } },
        interaction: { hover: true, dragNodes: true, dragView: true }
      };
      const network = new vis.Network(container, { nodes, edges }, options);

      network.once("stabilizationIterationsDone", () => network.setOptions({ physics: false }));

      // Ego‑network filter
      network.on("selectNode", params => {
        const sel = params.nodes[0];
        const keep = new Set([sel]);
        edges.forEach(e => {
          if (e.from === sel || e.to === sel) {
            keep.add(e.from);
            keep.add(e.to);
          }
        });
        nodes.forEach(n => nodes.update({ id: n.id, hidden: !keep.has(n.id) }));
        edges.forEach(e => edges.update({ id: e.id, hidden: !(e.from===sel||e.to===sel) }));
      });
      network.on("deselectNode", () => {
        nodes.forEach(n => nodes.update({ id: n.id, hidden: false }));
        edges.forEach(e => edges.update({ id: e.id, hidden: false }));
      });

      // Show logs on click
      network.on("click", params => {
        if (params.nodes.length === 1) {
          const id = params.nodes[0];
          nodes.update({ id, borderWidth: 6, color: { border: "red" } });
          fetch(`/user/${encodeURIComponent(id)}`)
            .then(r => r.text())
            .then(html => {
              const doc   = new DOMParser().parseFromString(html,"text/html");
              const items = doc.querySelectorAll("ul li");
              const panel = document.getElementById("log-panel");
              const list  = document.getElementById("log-list");
              document.getElementById("log-user").textContent = `Logs for ${id}`;
              list.innerHTML = ""; items.forEach(li=>list.appendChild(li));
              panel.style.display = "block";
            });
        }
      });
    })
    .catch(console.error);
});
