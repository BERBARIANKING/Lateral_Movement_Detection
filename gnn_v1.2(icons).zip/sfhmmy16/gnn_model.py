# gnn_model.py

import torch
import torch.nn.functional as F
import torch.nn as nn
from torch_geometric.nn import SAGEConv
from torch_geometric.utils import from_networkx

class GraphSAGE(nn.Module):
    def __init__(self, in_channels, hidden_channels, num_layers=2):
        super().__init__()
        self.convs = nn.ModuleList()
        # First layer
        self.convs.append(SAGEConv(in_channels, hidden_channels))
        # Additional layers
        for _ in range(num_layers - 1):
            self.convs.append(SAGEConv(hidden_channels, hidden_channels))
        # Final linear readout
        self.lin = nn.Linear(hidden_channels, 1)

    def forward(self, x, edge_index):
        for conv in self.convs:
            x = conv(x, edge_index)
            x = F.relu(x)
        return self.lin(x).squeeze()

class GNNAnomalyDetector:
    def __init__(self, graph, features):
        """
        graph: networkx.Graph
        features: numpy array [num_nodes, feat_dim]
        """
        # Convert to PyG Data
        pyg = from_networkx(graph)
        pyg.x = torch.tensor(features, dtype=torch.float)
        pyg.edge_index = pyg.edge_index
        self.data = pyg

        # Instantiate model
        in_dim = features.shape[1]
        self.model = GraphSAGE(in_dim, hidden_channels=16)

    def train(self, epochs=50, lr=0.01):
        optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
        for epoch in range(epochs):
            self.model.train()
            optimizer.zero_grad()
            pred = self.model(self.data.x, self.data.edge_index)
            actual = self.data.x.norm(dim=1)
            loss = F.mse_loss(pred, actual)
            loss.backward()
            optimizer.step()
            # if epoch % 10 == 0:
            #     print(f"[GNN] Epoch {epoch} loss: {loss.item():.4f}")

    def anomaly_scores(self):
        """
        Returns a numpy array of |predicted_norm – actual_norm| per node.
        Higher = more structurally anomalous.
        """
        self.model.eval()
        with torch.no_grad():
            pred   = self.model(self.data.x, self.data.edge_index)
            actual = self.data.x.norm(dim=1)
            error  = torch.abs(pred - actual)
        return error.numpy()
